const baseUrl = 'https://rms.naukri.com'
// SAMPLE LINK
// https://rms.naukri.com/profile/project/inbox/29925?token=cc74f54566b109d8bcf433d210279dfdia72c192a07f1706b30de8e1a4f4d9130
const existingEmails = ["indraprabha11@gmail.com",
    "yadavkyra94@gmail.com",
    "charu97gupta@gmail.com",
    "aryaamrita1995@gmail.com",
    "saxena.pal20@gmail.com",
    "kashishg966@gmail.com",
    "gauranchal99@gmail.com",
    "aditiarora0210@gmail.com",
    "shwetabansal088@gmail.com",
    "singhekta450@gmail.com"
]

let urls = Array.from(document.querySelectorAll('#ques_list>li')).reduce((result, ql) => {
    const profile = ql.querySelector('.profile').querySelector('em')
    const a = profile.querySelector('a');

    if (profile.contains(a)) {
        result.push(a.href)
    }

    return result
}, [])

// urls = [urls[0]]

setTimeout(() => {
    fetchResumes()
}, 100);

async function fetchResumes() {
    const allProfilesData = await Promise.all(
        urls.map(async url => {
            const res = await exeURL(url)
            const doc = document.createElement("div");
            doc.innerHTML = res;

            var candidateNodes = doc.querySelectorAll('.candDet')
            var profile = doc.querySelector('.hText').title.split(':')[1].trim()
            var profileUID = doc.querySelector('.quesPara').querySelector('small').innerHTML.trim()

            var resumes = await Promise.all(
                [...candidateNodes].map(async (node) => {
                    var email = node.querySelector('#emailIdForDisplay').title
                    if (!existingEmails.includes(email)) {
                        try {
                            let resumeBase64 = "NOT FOUND"
                            let hasResume = false
                            // var email = node.querySelector('#emailIdForDisplay').title
                            var profileId = node.querySelector('input[type=checkbox]').value
                            var applicationId = getApplicationID(node.querySelector('.candName').querySelector('a').href)
                            var linkToFindDocumentId = `${baseURL}/document/profile/${profileId}/candidatedocuments?limit=5&applicationId=${applicationId}`

                            let preDownloadDetails = await exeURL(linkToFindDocumentId)

                            if (preDownloadDetails && preDownloadDetails.documents.length) {
                                let endURL = preDownloadDetails.documents[0].downloadLink
                                let documentExtension = preDownloadDetails.documents[0].documentExtension
                                let documentName = preDownloadDetails.documents[0].documentName
                                resumeBase64 = await exeURL(baseURL + endURL, true)
                                hasResume = true
                                return { email, resumeBase64, hasResume, documentExtension, documentName }
                            } else {
                                return { email, resumeBase64, hasResume }
                            }
                        } catch (error) {
                            throw error
                        }
                    }
                })
            )
            resumes = resumes.length ? resumes.filter(r => r) : []
            return { data: resumes, profile, profileUID }
        })
    )
    console.log('%c --allProfilesData', 'color: #e50000', allProfilesData);
}

async function exeURL(url, specialFormat) {
    try {
        let params = {}
        if (specialFormat) {
            params = {
                responseType: 'arraybuffer'
            }
        }
        let response = await axios.get(url, params);
        if (specialFormat) {
            var uInt8Array = new Uint8Array(response.data)
            var i = uInt8Array.length;
            var biStr = new Array(i);
            while (i--) {
                biStr[i] = String.fromCharCode(uInt8Array[i]);
            }
            var data = biStr.join('');
            var base64 = window.btoa(data);

            return base64
        } else {
            return await response.data
        }
    } catch (error) {
        throw error
    }
}
